"""
Path 1 — Structured Logging (structlog)

Structured logging layer on top of Python's stdlib `logging`.
Provides JSON output, context binding via contextvars, processor pipelines,
and clean integration with stdlib log records from third-party libraries.
"""

from .config import (
    configure_auto_detect,
    configure_high_performance,
    configure_production_stdlib,
    configure_recommended_pipeline,
    create_processor_formatter,
    setup_stdlib_handler_with_formatter,
)
from .processors import add_trace_context

__all__ = [
    "configure_auto_detect",
    "configure_high_performance",
    "configure_production_stdlib",
    "configure_recommended_pipeline",
    "create_processor_formatter",
    "setup_stdlib_handler_with_formatter",
    "add_trace_context",
]
