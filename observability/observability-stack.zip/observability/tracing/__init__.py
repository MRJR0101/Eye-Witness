"""
Path 3 — Distributed Tracing (OpenTelemetry)

Vendor-neutral observability framework. Instrument once, export to any backend.
"""

from .provider import (
    setup_console_provider,
    setup_otlp_http_provider,
    setup_otlp_grpc_provider,
    get_tracer,
    shutdown_provider,
)
from .spans import traced, record_error
from .propagation import inject_context, extract_context
from .sampling import get_sampler
from .log_correlation import add_trace_context

__all__ = [
    "setup_console_provider",
    "setup_otlp_http_provider",
    "setup_otlp_grpc_provider",
    "get_tracer",
    "shutdown_provider",
    "traced",
    "record_error",
    "inject_context",
    "extract_context",
    "get_sampler",
    "add_trace_context",
]
