"""
OpenTelemetry Demo — Path 3 Complete Walkthrough

Exercises every pattern from the Path 3 reference:
  1. TracerProvider setup (ConsoleSpanExporter)
  2. Resource attributes (service.name, version, environment)
  3. Manual instrumentation (basic spans, nested spans)
  4. Span events (point-in-time annotations)
  5. Error status on spans (record_exception)
  6. Log correlation (trace_id / span_id in structlog)
  7. Context propagation (inject / extract)
  8. Sampling configuration
  9. CLI patterns (root span per invocation, shutdown)
  10. BatchSpanProcessor configuration notes

Run:  python -m observability.tracing.demo
"""

import structlog
from opentelemetry import trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import ConsoleSpanExporter, SimpleSpanProcessor
from opentelemetry.sdk.trace.sampling import TraceIdRatioBased
from opentelemetry.trace import Status, StatusCode
from opentelemetry.trace.propagation.tracecontext import TraceContextTextMapPropagator

from structlog.contextvars import clear_contextvars


def separator(title: str) -> None:
    bar = "=" * 70
    print(f"\n{bar}")
    print(f"  {title}")
    print(f"{bar}\n")


def main() -> None:
    print("\n  OpenTelemetry Path 3 — Complete Demo")
    print("  Using ConsoleSpanExporter for visibility\n")

    # ── 1. TracerProvider + Resource ─────────────────────────────────────
    separator("1. TracerProvider Setup (Console Exporter)")

    resource = Resource(attributes={
        "service.name": "demo-service",
        "service.version": "1.0.0",
        "deployment.environment": "development",
    })

    provider = TracerProvider(resource=resource)
    trace.set_tracer_provider(provider)
    provider.add_span_processor(SimpleSpanProcessor(ConsoleSpanExporter()))

    tracer = trace.get_tracer("demo.tracing")
    print("  TracerProvider configured with ConsoleSpanExporter")
    print("  Resource: service.name=demo-service, version=1.0.0")

    # ── 2. Basic Span ────────────────────────────────────────────────────
    separator("2. Basic Span with Attributes")

    with tracer.start_as_current_span("do_work") as span:
        span.set_attribute("work.input", 42)
        result = 42 * 2
        span.set_attribute("work.output", result)
        print(f"  Inside span 'do_work': input=42, output={result}")

    # ── 3. Nested Spans ──────────────────────────────────────────────────
    separator("3. Nested Spans (Parent-Child)")

    with tracer.start_as_current_span("process_order") as parent:
        parent.set_attribute("order.id", "ORD-001")

        with tracer.start_as_current_span("validate") as child:
            child.set_attribute("validation.type", "schema")
            print("  Inside child span 'validate'")

        with tracer.start_as_current_span("charge") as child:
            print("  Inside child span 'charge'")

    # ── 4. Span Events ───────────────────────────────────────────────────
    separator("4. Span Events (Point-in-Time Annotations)")

    with tracer.start_as_current_span("process") as span:
        span.add_event("validation.start")
        print("  Event: validation.start")
        span.add_event("validation.complete", {"valid": True})
        print("  Event: validation.complete (valid=True)")

    # ── 5. Error Status ──────────────────────────────────────────────────
    separator("5. Error Status on Spans")

    with tracer.start_as_current_span("risky_op") as span:
        try:
            raise ValueError("something went wrong")
        except Exception as e:
            span.set_status(Status(StatusCode.ERROR))
            span.record_exception(e)
            print(f"  Caught and recorded: {e}")

    # ── 6. Log Correlation ───────────────────────────────────────────────
    separator("6. Log Correlation (trace_id / span_id in structlog)")

    # Import the processor that bridges Path 1 <-> Path 3
    from observability.tracing.log_correlation import add_trace_context

    clear_contextvars()
    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            add_trace_context,  # <-- The bridge
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso", utc=True),
            structlog.processors.JSONRenderer(),
        ],
        cache_logger_on_first_use=False,
    )

    log = structlog.get_logger()

    with tracer.start_as_current_span("correlated_operation"):
        log.info("job.started", job_id="abc123")
        log.info("job.completed", job_id="abc123")

    # ── 7. Context Propagation ───────────────────────────────────────────
    separator("7. Context Propagation (inject / extract)")

    propagator = TraceContextTextMapPropagator()

    with tracer.start_as_current_span("outgoing-call"):
        carrier: dict[str, str] = {}
        propagator.inject(carrier)
        print(f"  Injected carrier: {carrier}")

    # Simulate receiving side
    if "traceparent" in carrier:
        ctx = propagator.extract(carrier=carrier)
        with tracer.start_as_current_span("incoming-handler", context=ctx):
            print("  Extracted context and created child span")

    # ── 8. Sampling ──────────────────────────────────────────────────────
    separator("8. Sampling Configuration")

    sampler = TraceIdRatioBased(1 / 1000)
    print(f"  TraceIdRatioBased(0.001) — sample 1 in 1000 traces")
    print("  Other options: ALWAYS_ON, ALWAYS_OFF, ParentBased")
    print("  Pass sampler to TracerProvider(sampler=sampler)")

    # ── 9. CLI Patterns ──────────────────────────────────────────────────
    separator("9. CLI Patterns")
    print("  Root span per invocation: tracer.start_as_current_span('cli.invoke')")
    print("  Set attributes: cli.command, cli.argv, cli.exit_code")
    print("  Shutdown provider on exit: provider.shutdown() or atexit.register()")

    # ── 10. BatchSpanProcessor Config ────────────────────────────────────
    separator("10. BatchSpanProcessor Configuration")
    print("  Env vars (all with OTEL_BSP_ prefix):")
    print("    OTEL_BSP_SCHEDULE_DELAY     = 5000ms (export interval)")
    print("    OTEL_BSP_MAX_QUEUE_SIZE     = 2048   (max queued spans)")
    print("    OTEL_BSP_MAX_EXPORT_BATCH_SIZE = 512 (max per export)")
    print("    OTEL_BSP_EXPORT_TIMEOUT     = 30000ms (export timeout)")

    # ── Packages ─────────────────────────────────────────────────────────
    separator("Packages Reference")
    packages = [
        ("opentelemetry-api",                     "Core API (trace, context, propagation)"),
        ("opentelemetry-sdk",                     "SDK (TracerProvider, processors, samplers)"),
        ("opentelemetry-exporter-console",        "ConsoleSpanExporter for local dev"),
        ("opentelemetry-exporter-otlp-proto-http", "OTLP over HTTP (port 4318)"),
        ("opentelemetry-exporter-otlp-proto-grpc", "OTLP over gRPC (port 4317)"),
        ("opentelemetry-exporter-otlp",           "Meta-package (HTTP + gRPC)"),
    ]
    for pkg, desc in packages:
        print(f"  {pkg:45s} {desc}")

    # ── Best Practices ───────────────────────────────────────────────────
    separator("Best Practices Summary (Path 3)")
    practices = [
        "Always set Resource attributes — service.name, version, environment",
        "Use BatchSpanProcessor in production — SimpleSpanProcessor for dev only",
        "Create one TracerProvider at startup — don't create multiple",
        "Name tracers by module — trace.get_tracer('myapp.module')",
        "Set error status on spans — span.set_status(Status(StatusCode.ERROR))",
        "Use record_exception() — attaches exception details to span",
        "Inject trace context into logs — highest-value OTel integration",
        "Shutdown provider on CLI exit — ensures buffered spans export",
        "Use env vars for config — OTEL_EXPORTER_OTLP_ENDPOINT",
        "Start with ConsoleSpanExporter — verify before adding remote export",
    ]
    for i, p in enumerate(practices, 1):
        print(f"  {i:2d}. {p}")
    print()
    print("  Done. All Path 3 patterns exercised.\n")

    # Shutdown
    provider.shutdown()


if __name__ == "__main__":
    main()
