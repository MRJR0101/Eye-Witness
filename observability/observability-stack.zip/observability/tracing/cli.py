"""
Path 3 — OpenTelemetry CLI-Specific Patterns

Root span per invocation and provider shutdown on exit.
"""

from __future__ import annotations

import atexit
import sys
from typing import Any, Callable, TypeVar

from opentelemetry import trace
from opentelemetry.trace import Status, StatusCode

T = TypeVar("T")


def cli_root_span(
    command_name: str, func: Callable[..., T],
    *args: Any, argv: list[str] | None = None, **kwargs: Any,
) -> T:
    """Wrap CLI command in a root span with command/argv/exit_code attributes."""
    tracer = trace.get_tracer("cli")
    if argv is None:
        argv = sys.argv[1:]

    with tracer.start_as_current_span("cli.invoke") as span:
        span.set_attribute("cli.command", command_name)
        span.set_attribute("cli.argv", " ".join(argv))

        try:
            result = func(*args, **kwargs)
            span.set_attribute("cli.exit_code", 0)
            return result
        except Exception as e:
            span.set_status(Status(StatusCode.ERROR))
            span.record_exception(e)
            span.set_attribute("cli.exit_code", 1)
            raise


def shutdown_provider() -> None:
    """Shutdown TracerProvider, flush buffered spans."""
    provider = trace.get_tracer_provider()
    if hasattr(provider, "shutdown"):
        provider.shutdown()


def register_shutdown_on_exit() -> None:
    """Register provider shutdown as atexit handler."""
    atexit.register(shutdown_provider)
