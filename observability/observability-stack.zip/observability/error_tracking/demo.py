"""
Sentry SDK Demo — Path 2 Complete Walkthrough

Exercises every pattern from the Path 2 reference:
  1. Full initialization with all key options
  2. LoggingIntegration (breadcrumbs from stdlib, manual event control)
  3. Breadcrumbs (http, query, ui, console, job)
  4. Context attachment (tags, structured context, user)
  5. Explicit exception capture
  6. Manual spans (performance tracing)
  7. CLI-specific patterns (flush on exit, command wrapping)
  8. No-DSN safety / GlitchTip compatibility

Run:  python -m observability.error_tracking.demo
"""

import logging

import sentry_sdk
from sentry_sdk.integrations.logging import LoggingIntegration

import structlog


def separator(title: str) -> None:
    bar = "=" * 70
    print(f"\n{bar}")
    print(f"  {title}")
    print(f"{bar}\n")


def main() -> None:
    print("\n  Sentry SDK Path 2 — Complete Demo")
    print("  (No DSN set — SDK runs in no-op mode, no data is sent)\n")

    # ── 1. Initialization ────────────────────────────────────────────────
    separator("1. Full Initialization (no-DSN = no-op)")

    sentry_logging = LoggingIntegration(
        level=None,        # Breadcrumbs from all log levels
        event_level=None,  # Don't auto-send log records as events
    )

    sentry_sdk.init(
        dsn="",                          # Empty = disabled / no-op
        release="demo-app@1.0.0",
        environment="local",
        traces_sample_rate=1.0,
        before_send=lambda event, hint: event,
        integrations=[sentry_logging],
        max_breadcrumbs=100,
        attach_stacktrace=True,
        send_default_pii=False,
    )
    print("  sentry_sdk.init() called with empty DSN (no-op mode)")
    print("  LoggingIntegration: level=None, event_level=None")

    # ── 2. Breadcrumbs ───────────────────────────────────────────────────
    separator("2. Breadcrumbs (context before the crash)")

    sentry_sdk.add_breadcrumb(
        category="http",
        message="GET /api/products",
        level="info",
        data={"status_code": 200, "response_time_ms": 120},
    )
    print("  Added HTTP breadcrumb: GET /api/products (200)")

    sentry_sdk.add_breadcrumb(
        category="query",
        message="Database query executed",
        level="info",
        data={
            "query": "SELECT * FROM orders WHERE user_id = ?",
            "duration_ms": 45,
            "rows_returned": 10,
        },
    )
    print("  Added query breadcrumb: SELECT * FROM orders...")

    sentry_sdk.add_breadcrumb(
        category="ui.click",
        message="User clicked 'Add to Cart' button",
        level="info",
        data={"product_id": "PROD-789", "price": 49.99},
    )
    print("  Added UI breadcrumb: Add to Cart click")

    sentry_sdk.add_breadcrumb(
        category="console",
        message="Validation failed for email field",
        level="warning",
    )
    print("  Added console breadcrumb: validation warning")

    sentry_sdk.add_breadcrumb(
        category="job",
        message="Processing batch",
        level="info",
        data={"job_id": "batch-001"},
    )
    print("  Added job breadcrumb: Processing batch")

    # ── 3. Context Attachment ────────────────────────────────────────────
    separator("3. Context Attachment (tags, context, user)")

    sentry_sdk.set_tag("job_id", "abc123")
    sentry_sdk.set_tag("api_version", "v2")
    print("  Tags set: job_id=abc123, api_version=v2")

    sentry_sdk.set_context("job", {
        "id": "abc123",
        "type": "data_pipeline",
        "input_rows": 50000,
    })
    print("  Context set: job={id, type, input_rows}")

    sentry_sdk.set_user({
        "id": "user-42",
        "username": "johndoe",
    })
    print("  User set: id=user-42, username=johndoe")

    # ── 4. Explicit Exception Capture ────────────────────────────────────
    separator("4. Explicit Exception Capture")

    log = structlog.get_logger()

    try:
        result = 1 / 0
    except Exception as e:
        print(f"  Caught: {e}")
        sentry_sdk.capture_exception(e)
        print("  capture_exception() called (no-op since DSN is empty)")

    sentry_sdk.capture_message("This is a non-exception condition", level="warning")
    print("  capture_message() called with level=warning")

    # ── 5. Manual Spans ──────────────────────────────────────────────────
    separator("5. Manual Spans (Performance Tracing)")

    with sentry_sdk.start_span(op="validation", description="Validate input"):
        print("  Inside validation span")

    with sentry_sdk.start_span(op="processing", description="Process data"):
        print("  Inside processing span")

    print("  Spans created (require traces_sample_rate > 0 to be captured)")

    # ── 6. CLI Patterns ──────────────────────────────────────────────────
    separator("6. CLI-Specific Patterns")

    import atexit
    atexit.register(lambda: sentry_sdk.flush(timeout=2))
    print("  Registered atexit flush handler")

    sentry_sdk.set_tag("cli.command", "demo")
    sentry_sdk.add_breadcrumb(category="cli", message="Running: demo", level="info")
    print("  CLI command tagged and breadcrumbed")

    # ── 7. GlitchTip Note ────────────────────────────────────────────────
    separator("7. GlitchTip Compatibility")
    print("  GlitchTip is a drop-in replacement for Sentry.")
    print("  Change DSN only — keep all sentry-sdk code unchanged.")
    print("  DSN format: https://<key>@<glitchtip-host>/<project-id>")
    print("  Supports: capture_exception, breadcrumbs, tags, context, releases")

    # ── Summary ──────────────────────────────────────────────────────────
    separator("Best Practices Summary (Path 2)")
    practices = [
        "Always make DSN optional — empty DSN = SDK disabled",
        "Use LoggingIntegration with event_level=None — manual event control",
        "Set release and environment — enables release grouping",
        "Use tags for searchable identifiers (job_id, command, api_version)",
        "Use context for structured debugging data (input params, config state)",
        "Add breadcrumbs at key checkpoints — story of what happened",
        "Capture exceptions explicitly with capture_exception()",
        "Flush before exit in CLI apps — atexit handler",
        "Start with traces_sample_rate=0.0 — enable when needed",
        "GlitchTip is a drop-in replacement — change DSN only",
    ]
    for i, p in enumerate(practices, 1):
        print(f"  {i:2d}. {p}")
    print()
    print("  Done. All Path 2 patterns exercised.\n")


if __name__ == "__main__":
    main()
