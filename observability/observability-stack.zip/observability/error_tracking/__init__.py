"""
Path 2 — Error Tracking (Sentry Python SDK)

Exception tracking, breadcrumbs, context attachment, performance tracing.
Supports a "no-DSN = no-op" pattern that makes it safe to include in
all environments without side effects.

Also compatible with GlitchTip (change DSN only, keep all SDK code).
"""

from .config import init_sentry, init_sentry_from_env
from .breadcrumbs import (
    add_http_breadcrumb,
    add_query_breadcrumb,
    add_ui_breadcrumb,
    add_console_breadcrumb,
    add_job_breadcrumb,
)
from .context import set_tags, set_structured_context, set_user
from .cli import flush_on_exit, wrap_command

__all__ = [
    "init_sentry",
    "init_sentry_from_env",
    "add_http_breadcrumb",
    "add_query_breadcrumb",
    "add_ui_breadcrumb",
    "add_console_breadcrumb",
    "add_job_breadcrumb",
    "set_tags",
    "set_structured_context",
    "set_user",
    "flush_on_exit",
    "wrap_command",
]
