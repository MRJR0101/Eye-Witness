"""
Sentry SDK Initialization — All patterns from Path 2 reference.

Sections:
  - Full initialization with all key options
  - LoggingIntegration (bridging stdlib logging -> Sentry)
  - No-DSN safety pattern
  - GlitchTip compatibility notes
"""

import os
from typing import Any, Callable

import sentry_sdk
from sentry_sdk.integrations.logging import LoggingIntegration


def init_sentry(
    dsn: str = "",
    *,
    release: str = "",
    environment: str = "production",
    traces_sample_rate: float = 0.0,
    before_send: Callable | None = None,
    before_send_transaction: Callable | None = None,
    max_breadcrumbs: int = 100,
    attach_stacktrace: bool = True,
    send_default_pii: bool = False,
    server_name: str = "",
) -> None:
    """
    Initialize Sentry SDK with all key options from the reference.

    Args:
        dsn: Sentry project DSN. Empty string = SDK disabled (no-op).
        release: Version tag for grouping issues by release.
        environment: Environment name (local, staging, production).
        traces_sample_rate: Fraction of transactions to capture (0.0-1.0).
        before_send: Callback to filter/modify events before sending.
        before_send_transaction: Callback to filter transactions.
        max_breadcrumbs: Max breadcrumbs stored per event.
        attach_stacktrace: Attach stack traces even to non-exception events.
        send_default_pii: Include request bodies, cookies, user IPs.
        server_name: Override machine identifier.
    """
    # LoggingIntegration: capture breadcrumbs from all stdlib logging,
    # but do NOT auto-send log records as events (control manually).
    sentry_logging = LoggingIntegration(
        level=None,         # Breadcrumbs from all log levels
        event_level=None,   # Don't auto-send log records as events
    )

    init_kwargs: dict[str, Any] = {
        "dsn": dsn,
        "environment": environment,
        "integrations": [sentry_logging],
        "max_breadcrumbs": max_breadcrumbs,
        "attach_stacktrace": attach_stacktrace,
        "send_default_pii": send_default_pii,
        "traces_sample_rate": traces_sample_rate,
    }

    if release:
        init_kwargs["release"] = release
    if before_send:
        init_kwargs["before_send"] = before_send
    if before_send_transaction:
        init_kwargs["before_send_transaction"] = before_send_transaction
    if server_name:
        init_kwargs["server_name"] = server_name

    sentry_sdk.init(**init_kwargs)


def init_sentry_from_env(
    *,
    release: str = "",
    environment: str = "",
) -> None:
    """
    Initialize Sentry from environment variables.

    Reads SENTRY_DSN from env. Empty or missing = SDK disabled (no-op).
    Also reads SENTRY_ENVIRONMENT if environment is not passed.

    This is the no-DSN safety pattern from the reference:
    empty DSN = no network calls, no side effects.
    """
    dsn = os.getenv("SENTRY_DSN", "").strip()
    if not environment:
        environment = os.getenv("SENTRY_ENVIRONMENT", "production")

    init_sentry(dsn=dsn, release=release, environment=environment)
